import './App.css';
import UserDashboard from './components/UserDashboard';

function App() {
  return (
    <div className="App">
      <UserDashboard />
    </div>
  );
}

export default App;
